(()=>{var a={};a.id=1469,a.ids=[1469],a.modules={1708:a=>{"use strict";a.exports=require("node:process")},55591:a=>{"use strict";a.exports=require("https")},74075:a=>{"use strict";a.exports=require("zlib")},78335:()=>{},111723:a=>{"use strict";a.exports=require("querystring")},134631:a=>{"use strict";a.exports=require("tls")},157075:a=>{"use strict";a.exports=require("node:stream")},163945:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>C,patchFetch:()=>B,routeModule:()=>x,serverHooks:()=>A,workAsyncStorage:()=>y,workUnitAsyncStorage:()=>z});var d={};c.r(d),c.d(d,{POST:()=>w});var e=c(595736),f=c(9117),g=c(604044),h=c(139326),i=c(532324),j=c(200261),k=c(954290),l=c(85328),m=c(438928),n=c(146595),o=c(903421),p=c(817679),q=c(541681),r=c(863446),s=c(986439),t=c(151356),u=c(410641),v=c(806329);async function w(a){try{let{email:b,subject:c,customMessage:d}=await a.json();if(!b)return u.NextResponse.json({success:!1,error:"Email is required"},{status:400});let e=(()=>{for(let a of["GMAIL_CLIENT_ID","GMAIL_CLIENT_SECRET","GMAIL_REFRESH_TOKEN","GMAIL_USER_EMAIL"])if(!process.env[a])throw Error(`Missing required environment variable: ${a}`);return new v.D({gmail:{clientId:process.env.GMAIL_CLIENT_ID,clientSecret:process.env.GMAIL_CLIENT_SECRET,refreshToken:process.env.GMAIL_REFRESH_TOKEN,user:process.env.GMAIL_USER_EMAIL},options:{companyName:process.env.COMPANY_NAME||"SomlengP",expiryMinutes:parseInt(process.env.OTP_EXPIRY_MINUTES||"5")}})})(),f=await e.resendOTP(b,{subject:c||"Your New Verification Code",customMessage:d});if(f.success)return u.NextResponse.json({success:!0,messageId:f.messageId,message:"New OTP sent successfully"});return u.NextResponse.json({success:!1,error:f.error},{status:400})}catch(a){if(a instanceof Error&&a.message.includes("Missing required environment variable"))return u.NextResponse.json({success:!1,error:"Service configuration error"},{status:500});return u.NextResponse.json({success:!1,error:"Failed to resend OTP"},{status:500})}}let x=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/otp/resend/route",pathname:"/api/otp/resend",filename:"route",bundlePath:"app/api/otp/resend/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"C:\\Users\\GS Computer\\Downloads\\Telegram Desktop\\somlengp\\src\\app\\api\\otp\\resend\\route.ts",nextConfigOutput:"standalone",userland:d}),{workAsyncStorage:y,workUnitAsyncStorage:z,serverHooks:A}=x;function B(){return(0,g.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:z})}async function C(a,b,c){var d;let e="/api/otp/resend/route";"/index"===e&&(e="/");let g=await x.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:y,prerenderManifest:z,routerServerContext:A,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,resolvedPathname:D}=g,E=(0,j.normalizeAppPath)(e),F=!!(z.dynamicRoutes[E]||z.routes[D]);if(F&&!y){let a=!!z.routes[D],b=z.dynamicRoutes[E];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let G=null;!F||x.isDev||y||(G="/index"===(G=D)?"/":G);let H=!0===x.isDev||!F,I=F&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:z,renderOpts:{experimental:{cacheComponents:!!w.experimental.cacheComponents,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>x.onRequestError(a,b,d,A)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>x.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&B&&C&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!F)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await x.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})},A),b}},l=await x.handleResponse({req:a,nextConfig:w,cacheKey:G,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:z,isRoutePPREnabled:!1,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,responseGenerator:k,waitUntil:c.waitUntil});if(!F)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",B?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),y&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&F||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(L||b instanceof s.NoFallbackError||await x.onRequestError(a,b,{routerKind:"App Router",routePath:E,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})}),F)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},173136:a=>{"use strict";a.exports=require("node:url")},173566:a=>{"use strict";a.exports=require("worker_threads")},176760:a=>{"use strict";a.exports=require("node:path")},200261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},257975:a=>{"use strict";a.exports=require("node:util")},296487:()=>{},321820:a=>{"use strict";a.exports=require("os")},328354:a=>{"use strict";a.exports=require("util")},333873:a=>{"use strict";a.exports=require("path")},337830:a=>{"use strict";a.exports=require("node:stream/web")},344708:a=>{"use strict";a.exports=require("node:https")},379551:a=>{"use strict";a.exports=require("url")},419121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},455511:a=>{"use strict";a.exports=require("crypto")},491645:a=>{"use strict";a.exports=require("net")},504573:a=>{"use strict";a.exports=require("node:buffer")},529294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},579646:a=>{"use strict";a.exports=require("child_process")},583997:a=>{"use strict";a.exports=require("tty")},594735:a=>{"use strict";a.exports=require("events")},629021:a=>{"use strict";a.exports=require("fs")},638522:a=>{"use strict";a.exports=require("node:zlib")},663033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},673496:a=>{"use strict";a.exports=require("http2")},710846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},714985:a=>{"use strict";a.exports=require("dns")},719771:a=>{"use strict";a.exports=require("process")},744870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},777030:a=>{"use strict";a.exports=require("node:net")},781630:a=>{"use strict";a.exports=require("http")},806329:(a,b,c)=>{"use strict";c.d(b,{D:()=>k});var d=c(455511),e=c.n(d);let f=new Map;class g{static{this.CODE_LENGTH=6}static{this.EXPIRY_MINUTES=5}static{this.MAX_ATTEMPTS=3}static generateOTP(){return e().randomInt(1e5,999999).toString()}static storeOTP(a,b){let c=a.toLowerCase().trim(),d=new Date;d.setMinutes(d.getMinutes()+this.EXPIRY_MINUTES),f.set(c,{code:b,email:c,expires:d,attempts:0,createdAt:new Date})}static verifyOTP(a,b){let c=a.toLowerCase().trim(),d=f.get(c);return d?new Date>d.expires?(f.delete(c),{success:!1,error:"OTP has expired. Please request a new code."}):d.attempts>=this.MAX_ATTEMPTS?(f.delete(c),{success:!1,error:"Maximum verification attempts exceeded. Please request a new code."}):(d.attempts++,d.code===b)?(f.delete(c),{success:!0}):(f.set(c,d),{success:!1,error:"Invalid OTP code.",attemptsRemaining:this.MAX_ATTEMPTS-d.attempts}):{success:!1,error:"OTP not found. Please request a new code."}}static cleanupExpired(){let a=new Date;for(let[b,c]of f.entries())a>c.expires&&f.delete(b)}static getOTPStatus(a){let b=a.toLowerCase().trim(),c=f.get(b);return c?{exists:!0,expires:c.expires,attempts:c.attempts,maxAttempts:this.MAX_ATTEMPTS}:{exists:!1}}static removeOTP(a){let b=a.toLowerCase().trim();f.delete(b)}}setInterval(()=>{g.cleanupExpired()},6e4);var h=c(252731),i=c(667859);class j{constructor(a){this.transporter=null,this.config=a}async initializeTransporter(){try{let a=new i.q7g.auth.OAuth2(this.config.clientId,this.config.clientSecret,"https://developers.google.com/oauthplayground");a.setCredentials({refresh_token:this.config.refreshToken});let b=await a.getAccessToken();this.transporter=h.createTransport({service:"gmail",auth:{type:"OAuth2",user:this.config.user,clientId:this.config.clientId,clientSecret:this.config.clientSecret,refreshToken:this.config.refreshToken,accessToken:b.token||""}})}catch(a){throw Error("Failed to initialize Gmail service")}}async sendOTPEmail(a,b,c){try{this.transporter||await this.initializeTransporter();let{subject:d="Your Verification Code",companyName:e="SomlengP",expiryMinutes:f=5}=c||{},g=this.generateOTPEmailHTML(a,e,f),h=this.generateOTPEmailText(a,e,f),i={from:`${e} <${this.config.user}>`,to:b,subject:d,text:h,html:g},j=await this.transporter.sendMail(i);return{success:!0,messageId:j.messageId}}catch(a){return{success:!1,error:a instanceof Error?a.message:"Unknown error occurred"}}}generateOTPEmailHTML(a,b,c){return`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Verification Code</title>
        <style>
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
          }
          .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
          }
          .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 300;
          }
          .content {
            padding: 40px 30px;
            text-align: center;
          }
          .otp-code {
            font-size: 36px;
            font-weight: bold;
            color: #667eea;
            background-color: #f8f9ff;
            padding: 20px;
            border-radius: 8px;
            letter-spacing: 8px;
            margin: 30px 0;
            display: inline-block;
            border: 2px dashed #667eea;
          }
          .message {
            font-size: 16px;
            margin-bottom: 20px;
            color: #555;
          }
          .expiry-notice {
            font-size: 14px;
            color: #e74c3c;
            background-color: #fdf2f2;
            padding: 15px;
            border-radius: 6px;
            border-left: 4px solid #e74c3c;
            margin: 20px 0;
          }
          .footer {
            background-color: #f8f9fa;
            padding: 20px 30px;
            text-align: center;
            font-size: 12px;
            color: #666;
          }
          .security-note {
            background-color: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin: 20px 0;
            font-size: 14px;
            color: #856404;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>${b}</h1>
            <p>Verification Code</p>
          </div>
          <div class="content">
            <p class="message">
              Please use the verification code below to complete your action:
            </p>
            <div class="otp-code">${a}</div>
            <div class="expiry-notice">
              ⏰ This code will expire in ${c} minutes
            </div>
            <div class="security-note">
              🔒 <strong>Security Note:</strong> Never share this code with anyone. ${b} will never ask for your verification code via phone or email.
            </div>
          </div>
          <div class="footer">
            <p>This is an automated message from ${b}.</p>
            <p>If you didn't request this code, please ignore this email.</p>
          </div>
        </div>
      </body>
      </html>
    `}generateOTPEmailText(a,b,c){return`
${b} - Verification Code

Your verification code is: ${a}

This code will expire in ${c} minutes.

For security reasons:
- Never share this code with anyone
- ${b} will never ask for your verification code

If you didn't request this code, please ignore this email.

---
This is an automated message from ${b}.
    `.trim()}async testConnection(){try{return this.transporter||await this.initializeTransporter(),await this.transporter.verify(),{success:!0}}catch(a){return{success:!1,error:a instanceof Error?a.message:"Connection test failed"}}}}class k{constructor(a){this.gmailService=new j(a.gmail),this.options={companyName:a.options?.companyName||"SomlengP",expiryMinutes:a.options?.expiryMinutes||5}}async sendOTP(a,b){try{if(!this.isValidEmail(a))return{success:!1,error:"Invalid email format"};let c=g.getOTPStatus(a);if(c.exists){let a=c.expires?Math.ceil((c.expires.getTime()-new Date().getTime())/1e3/60):0;return{success:!1,error:`An OTP is already active for this email. Please wait ${a} minutes or use the existing code.`}}let d=g.generateOTP();g.storeOTP(a,d);let e=await this.gmailService.sendOTPEmail(d,a,{subject:b?.subject,companyName:this.options.companyName,expiryMinutes:this.options.expiryMinutes});if(!e.success)return g.removeOTP(a),{success:!1,error:`Failed to send email: ${e.error}`};return{success:!0,code:d,messageId:e.messageId}}catch(a){return{success:!1,error:a instanceof Error?a.message:"Failed to send OTP"}}}async verifyOTP(a,b){try{if(!this.isValidEmail(a))return{success:!1,error:"Invalid email format"};if(!b||6!==b.length||!/^\d{6}$/.test(b))return{success:!1,error:"Invalid OTP format. Code must be 6 digits."};return g.verifyOTP(a,b)}catch(a){return{success:!1,error:a instanceof Error?a.message:"Failed to verify OTP"}}}async resendOTP(a,b){try{return g.removeOTP(a),await this.sendOTP(a,b)}catch(a){return{success:!1,error:a instanceof Error?a.message:"Failed to resend OTP"}}}getOTPStatus(a){let b=g.getOTPStatus(a);if(b.exists&&b.expires){let a=Math.max(0,Math.floor((b.expires.getTime()-new Date().getTime())/1e3));return{...b,timeRemaining:a}}return b}cancelOTP(a){try{return g.removeOTP(a),{success:!0}}catch(a){return{success:!1}}}async testConnection(){return await this.gmailService.testConnection()}isValidEmail(a){return/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(a)}getStats(){return{activeOTPs:0,serviceName:this.options.companyName,version:"1.0.0"}}}},903295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},912412:a=>{"use strict";a.exports=require("assert")},927910:a=>{"use strict";a.exports=require("stream")},937067:a=>{"use strict";a.exports=require("node:http")},973024:a=>{"use strict";a.exports=require("node:fs")},979428:a=>{"use strict";a.exports=require("buffer")},986439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")}};var b=require("../../../../webpack-runtime.js");b.C(a);var c=b.X(0,[8561,6284,5237,9299,563,7218,3563,9420,9560,5021,95,4269,8209,2150,1032,2687,2724,9435,5770,1964,2535,6014,5496,6259,8695,381,714,468,4691,7166,2633,106,9515,6306,9110,9453,1443,1843,2093,4145,5811,6110,6577,4644,4246,3025,1630,1814,962,3208,7891,6797,3679,9006,6635,9758,6597,8186,4861,8237,8495,8992,9792,6550,1278,7241,5193,4283,6785,9425,3238,4607,2620,2907,401,9822,2018,1094,1307,7773,8540,1477,9164,7429,2411,3142,2911,5694,3918,8542,2055,814,3765,3486,3004,4402,6029,2880,7727,177,2303,2404,715,2762,4255,3999,9341,7623,6140,4826,158,8576,9134,1290,625,8740,2435,1064,6239,7667,4319,2345,1326,670,116,5495,1408,3092,1698,139,5560,5542,9738,3936,667,6870,8588,923,5251,7307,1340,1563,6703,1743,5886,7105,8802,8373,629,6312,8918,2858,4486,2784,7967,271,3565,3271,1277,9051,2152,4842,6002,8827,9199,944,3697,3894,8333,9698,1936,3913,5399,622,7708,2432,3589,5030,8392,4436,4941,3719,2860,2324,9388,1618,6113,1966,7445,4590,6119,843,2623,717,5814,5068,2847,8565,2419,1787,9843,1938,677,5660,1549,2854,6012,8081,1128,6995,1488,5406,302,6195,4170,6424,2609,2802,884,6359,1897,7737,3957,7479,540,2296,8049,6137,2707,8007,1021,4864,9480,9653,7339,6503,172,5590,8907,3699,9219,545,1223,6304,387,8515,9884,1555,6349,5902,3376,4163,7432,2199,8925,8174,3440,9184,1653,4786,852],()=>b(b.s=163945));module.exports=c})();