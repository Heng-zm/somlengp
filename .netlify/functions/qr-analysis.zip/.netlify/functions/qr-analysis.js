"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// .netlify/functions/qr-analysis.ts
var qr_analysis_exports = {};
__export(qr_analysis_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(qr_analysis_exports);
function analyzeQRContent(input) {
  const startTime = Date.now();
  let riskLevel = "low";
  let riskScore = 10;
  const threats = [];
  const recommendations = [];
  const content = input.content.toLowerCase();
  if (content.includes("http://")) {
    riskScore += 20;
    threats.push({
      type: "Insecure Protocol",
      description: "Uses HTTP instead of HTTPS",
      severity: "medium"
    });
    recommendations.push("Verify the website uses HTTPS before visiting");
  }
  if (content.match(/\.(exe|bat|scr|zip|rar|msi|dmg|pkg)$/i)) {
    riskScore += 40;
    threats.push({
      type: "Executable File",
      description: "Links to potentially dangerous file types",
      severity: "high"
    });
    recommendations.push("Do not download or execute files from unknown sources");
  }
  const suspiciousDomains = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly"];
  const hasSuspiciousDomain = suspiciousDomains.some((domain) => content.includes(domain));
  if (hasSuspiciousDomain) {
    riskScore += 15;
    threats.push({
      type: "Shortened URL",
      description: "Contains shortened URL that hides the real destination",
      severity: "medium"
    });
    recommendations.push("Be cautious with shortened URLs - verify the destination");
  }
  const phishingKeywords = ["login", "signin", "password", "account", "verify", "suspended", "urgent", "winner", "prize"];
  const foundKeywords = phishingKeywords.filter((keyword) => content.includes(keyword));
  if (foundKeywords.length > 0) {
    riskScore += foundKeywords.length * 5;
    threats.push({
      type: "Potential Phishing",
      description: `Contains suspicious keywords: ${foundKeywords.join(", ")}`,
      severity: "medium"
    });
    recommendations.push("Be cautious of requests for personal information");
  }
  if (content.match(/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/)) {
    riskScore += 25;
    threats.push({
      type: "IP Address",
      description: "Uses IP address instead of domain name",
      severity: "medium"
    });
    recommendations.push("Be extra cautious with direct IP addresses");
  }
  if (riskScore >= 70) {
    riskLevel = "critical";
  } else if (riskScore >= 45) {
    riskLevel = "high";
  } else if (riskScore >= 25) {
    riskLevel = "medium";
  }
  let primaryCategory = "Unknown";
  const subcategories = [];
  const suggestedTags = [input.type];
  if (input.type === "url" || content.startsWith("http")) {
    primaryCategory = "Website Link";
    subcategories.push("URL");
    suggestedTags.push("web", "link");
  } else if (input.type === "wifi") {
    primaryCategory = "WiFi Credentials";
    subcategories.push("Network");
    suggestedTags.push("wifi", "network", "credentials");
  } else if (input.type === "text") {
    primaryCategory = "Text Content";
    subcategories.push("Plain Text");
    suggestedTags.push("text", "message");
  } else if (input.type === "email") {
    primaryCategory = "Email";
    subcategories.push("Contact");
    suggestedTags.push("email", "contact");
  } else if (input.type === "phone") {
    primaryCategory = "Phone Number";
    subcategories.push("Contact");
    suggestedTags.push("phone", "contact");
  } else if (input.type === "sms") {
    primaryCategory = "SMS Message";
    subcategories.push("Messaging");
    suggestedTags.push("sms", "message");
  }
  const keyInformation = [
    {
      label: "Content Type",
      value: input.type,
      importance: "high"
    },
    {
      label: "Content Length",
      value: `${input.content.length} characters`,
      importance: "low"
    },
    {
      label: "Risk Assessment",
      value: `${riskLevel} risk (${riskScore}/100)`,
      importance: "high"
    }
  ];
  const relatedActions = [];
  if (primaryCategory === "Website Link") {
    relatedActions.push({
      action: "Verify URL",
      description: "Check the URL for legitimacy before visiting",
      priority: riskLevel === "low" ? "medium" : "high"
    });
  } else if (primaryCategory === "WiFi Credentials") {
    relatedActions.push({
      action: "Connect to WiFi",
      description: "Use the provided credentials to connect to the network",
      priority: "medium"
    });
  }
  if (recommendations.length === 0) {
    recommendations.push("Content appears to be safe, but always use caution with QR codes");
  }
  return {
    security: {
      riskLevel,
      riskScore: Math.min(100, Math.max(0, riskScore)),
      threats,
      recommendations
    },
    categorization: {
      primaryCategory,
      subcategories,
      confidence: 0.8,
      suggestedTags
    },
    insights: {
      summary: `QR code contains ${primaryCategory.toLowerCase()} with ${riskLevel} security risk (${riskScore}/100).`,
      keyInformation,
      relatedActions
    },
    metadata: {
      analysisDate: startTime,
      confidence: 0.8,
      processingTime: Date.now() - startTime,
      version: "1.0"
    }
  };
}
var handler = async (event, context) => {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: corsHeaders,
      body: JSON.stringify({ error: "Method not allowed. Use POST." })
    };
  }
  try {
    if (!event.body) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: "Request body is required" })
      };
    }
    let requestData;
    try {
      requestData = JSON.parse(event.body);
    } catch (parseError) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: "Invalid JSON in request body" })
      };
    }
    if (!requestData.content || !requestData.type) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({
          error: "Missing required fields: content and type are required"
        })
      };
    }
    console.log("Starting QR code analysis for type:", requestData.type);
    const analysisResult = analyzeQRContent(requestData);
    return {
      statusCode: 200,
      headers: {
        ...corsHeaders,
        "Cache-Control": "no-cache"
      },
      body: JSON.stringify({
        success: true,
        analysis: analysisResult,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  } catch (error) {
    console.error("QR Code Analysis Error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error occurred";
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        success: false,
        error: "QR code analysis failed",
        details: errorMessage,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
